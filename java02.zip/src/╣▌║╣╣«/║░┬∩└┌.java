package �ݺ���;

import java.util.Scanner;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

public class ������ {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�ݺ� Ƚ�� �Է� >> ");
		int count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			System.out.println("*");
		}

	}

}
