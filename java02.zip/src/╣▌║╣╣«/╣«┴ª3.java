package �ݺ���;

public class ����3 {

	public static void main(String[] args) {
		// �ǽ�
		for (int i = 0; i < 10; i++) {
			System.out.print("*");
		}
		
		System.out.println();
		
		for (int i = 0; i < 5; i++) {
			System.out.print("Ŀ��*");
		}
		
		for (int i = 0; i < 3; i++) {
			System.out.println("Ŀ��*����");
		}
		
		for (int i = 0; i < 3; i++) {
			System.out.println((i + 1) + " : ¯!");
		}

	}

}
